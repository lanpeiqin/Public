# Dicom_3D_Reconstruction
Based on VTK and python

Dicom_3D_Reconstruction have two ways, one is Volume rendering, another is Surface rendering

In surface rendering, we have two ways, one is MC algorithm, another is vtkContourFilter().

if u want to download this Dicom image or talk about Dicom_3D_Reconstruction with me, welcome to chat QQnumber: 1184808123

SR_dicom: use vtkContourFilter() to complete Dicom_3D_Reconstruction

VR_dicom: use Volume rendering to complete Dicom_3D_Reconstruction

SR_dicom_with_MC: use MC algorithm to complete Dicom_3D_Reconstruction

u can see more information through my blog:https://www.cnblogs.com/XDU-Lakers/p/10822840.html
